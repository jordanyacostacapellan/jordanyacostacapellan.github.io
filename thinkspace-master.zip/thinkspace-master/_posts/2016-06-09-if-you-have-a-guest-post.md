---
layout: post
title: "If you have a Guest post.."
comments: true
description: "If you have a Guest post.."
keywords: "dummy content"
author: GuestName
---

If you think that you're going to have a guest post... take a look on this post sample. Just add `author: GuestName` to the YAML front matter. Then, the **GuestName** will be appear on the next of post date. Oh, the guest name will be automatically uppercase.
